package com.tequila.ecommerce.vinoteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaleWineApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaleWineApplication.class, args);
	}

}
