package com.tequila.ecommerce.vinoteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaleWineApplicationTests {

	@Test
	void contextLoads() {
	}

}
